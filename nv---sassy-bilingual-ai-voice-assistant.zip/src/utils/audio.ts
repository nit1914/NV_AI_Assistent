/**
 * Decodes a base64 PCM16 24kHz string into a Float32Array
 */
export function base64ToFloat32PCM(base64: string): Float32Array {
  const binaryString = window.atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  const int16Array = new Int16Array(bytes.buffer);
  const float32Array = new Float32Array(int16Array.length);
  for (let i = 0; i < int16Array.length; i++) {
    float32Array[i] = int16Array[i] / 32768; // Normalize signed int16 to [-1, 1]
  }
  return float32Array;
}

/**
 * Converts a Float32Array to signed 16-bit PCM (Int16Array) binary
 */
export function floatTo16BitPCM(float32Array: Float32Array): ArrayBuffer {
  const buffer = new ArrayBuffer(float32Array.length * 2);
  const view = new DataView(buffer);
  let offset = 0;
  for (let i = 0; i < float32Array.length; i++, offset += 2) {
    const s = Math.max(-1, Math.min(1, float32Array[i]));
    // Convert to signed 16-bit integer
    view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true); // little-endian
  }
  return buffer;
}

/**
 * Converts an ArrayBuffer to a Base64 string
 */
export function arrayBufferToBase64(buffer: ArrayBuffer): string {
  let binary = "";
  const bytes = new Uint8Array(buffer);
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return window.btoa(binary);
}

/**
 * Resamples a Float32Array buffer from a source sample rate to a target sample rate
 */
export function downsample(buffer: Float32Array, fromRate: number, toRate: number): Float32Array {
  if (fromRate === toRate) {
    return buffer;
  }
  if (toRate > fromRate) {
    console.warn("Target sample rate cannot be higher than source, returning original");
    return buffer;
  }
  const sampleRateRatio = fromRate / toRate;
  const newLength = Math.round(buffer.length / sampleRateRatio);
  const result = new Float32Array(newLength);
  let offsetResult = 0;
  let offsetBuffer = 0;
  while (offsetResult < result.length) {
    const nextOffsetBuffer = Math.round((offsetResult + 1) * sampleRateRatio);
    let accum = 0;
    let count = 0;
    for (let i = offsetBuffer; i < nextOffsetBuffer && i < buffer.length; i++) {
      accum += buffer[i];
      count++;
    }
    result[offsetResult] = count > 0 ? accum / count : 0;
    offsetResult++;
    offsetBuffer = nextOffsetBuffer;
  }
  return result;
}

/**
 * Scheduled audio player for gapless 24kHz output playback
 */
export class ScheduledAudioPlayer {
  private ctx: AudioContext | null = null;
  private nextStartTime: number = 0;
  private activeSources: AudioBufferSourceNode[] = [];
  private onSpeakingChange?: (isSpeaking: boolean) => void;
  public analyserNode: AnalyserNode | null = null;

  constructor(onSpeakingChange?: (isSpeaking: boolean) => void) {
    this.onSpeakingChange = onSpeakingChange;
  }

  init(ctx: AudioContext) {
    this.ctx = ctx;
    this.nextStartTime = 0;
    this.activeSources = [];
    this.analyserNode = ctx.createAnalyser();
    this.analyserNode.fftSize = 256;
    this.analyserNode.connect(ctx.destination);
  }

  playChunk(base64Data: string) {
    if (!this.ctx) return;
    if (this.ctx.state === "suspended") {
      this.ctx.resume().catch((e) => console.error("Error resuming AudioContext:", e));
    }

    const floatSamples = base64ToFloat32PCM(base64Data);
    if (floatSamples.length === 0) return;

    // Create an AudioBuffer at 24000Hz (the frequency returned by Gemini Live voice responses)
    const audioBuffer = this.ctx.createBuffer(1, floatSamples.length, 24000);
    audioBuffer.getChannelData(0).set(floatSamples);

    const source = this.ctx.createBufferSource();
    source.buffer = audioBuffer;
    
    // Connect to speech analyser to drive high-fidelity visualizations
    if (this.analyserNode) {
      source.connect(this.analyserNode);
    } else {
      source.connect(this.ctx.destination);
    }

    const currentTime = this.ctx.currentTime;
    
    // Add buffering margin (50ms) to avoid stuttering due to network arrival jitter
    const minStartTime = currentTime + 0.05;
    if (this.nextStartTime < minStartTime) {
      this.nextStartTime = minStartTime;
    }

    source.start(this.nextStartTime);
    this.nextStartTime += audioBuffer.duration;
    
    this.activeSources.push(source);
    if (this.onSpeakingChange) {
      this.onSpeakingChange(true);
    }

    source.onended = () => {
      // Remove from active sources list
      const index = this.activeSources.indexOf(source);
      if (index > -1) {
        this.activeSources.splice(index, 1);
      }
      if (this.activeSources.length === 0 && this.onSpeakingChange) {
        this.onSpeakingChange(false);
      }
    };
  }

  stop() {
    this.activeSources.forEach((source) => {
      try {
        source.stop();
      } catch (err) {
        // Source may have already ended
      }
    });
    this.activeSources = [];
    this.nextStartTime = 0;
    if (this.onSpeakingChange) {
      this.onSpeakingChange(false);
    }
  }

  getIsPlaying() {
    return this.activeSources.length > 0;
  }
}

/**
 * Audio Recorder for capturing mic input and downsampling to 16kHz PCM16 with active noise cancellation options
 */
export class MicrophoneRecorder {
  private ctx: AudioContext | null = null;
  private stream: MediaStream | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private processorNode: ScriptProcessorNode | null = null;
  private onAudioChunk: (base64PCM16: string, rms: number) => void;
  public analyserNode: AnalyserNode | null = null;

  // Real-time Noise Cancellation & Noise Gate control states
  public noiseGateEnabled: boolean = true;
  public noiseGateThreshold: number = 0.015;
  public browserNoiseSuppression: boolean = true;
  public browserEchoCancellation: boolean = true;
  public browserAutoGainControl: boolean = true;

  constructor(
    onAudioChunk: (base64PCM16: string, rms: number) => void,
    options?: {
      noiseGateEnabled?: boolean;
      noiseGateThreshold?: number;
      browserNoiseSuppression?: boolean;
      browserEchoCancellation?: boolean;
      browserAutoGainControl?: boolean;
    }
  ) {
    this.onAudioChunk = onAudioChunk;
    if (options) {
      if (options.noiseGateEnabled !== undefined) this.noiseGateEnabled = options.noiseGateEnabled;
      if (options.noiseGateThreshold !== undefined) this.noiseGateThreshold = options.noiseGateThreshold;
      if (options.browserNoiseSuppression !== undefined) this.browserNoiseSuppression = options.browserNoiseSuppression;
      if (options.browserEchoCancellation !== undefined) this.browserEchoCancellation = options.browserEchoCancellation;
      if (options.browserAutoGainControl !== undefined) this.browserAutoGainControl = options.browserAutoGainControl;
    }
  }

  async start() {
    // 1. Get user mic media stream with active hardware-level noise suppression configs
    this.stream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: this.browserEchoCancellation,
        noiseSuppression: this.browserNoiseSuppression,
        autoGainControl: this.browserAutoGainControl,
      },
    });

    // 2. Initialize AudioContext at native hardware sample rate to guarantee compatibility
    this.ctx = new AudioContext();
    this.sourceNode = this.ctx.createMediaStreamSource(this.stream);

    // Create microphone signal analyser for input level visualization
    this.analyserNode = this.ctx.createAnalyser();
    this.analyserNode.fftSize = 256;
    this.sourceNode.connect(this.analyserNode); // Analyzes input buffer, but does not pipe to output speaker destination!

    // 3. Create ScriptProcessor with appropriate buffer size
    const bufferSize = 4096;
    this.processorNode = this.ctx.createScriptProcessor(bufferSize, 1, 1);

    const inputSampleRate = this.ctx.sampleRate;
    const targetSampleRate = 16000; // Gemini Live API strictly requires 16kHz audio input

    this.processorNode.onaudioprocess = (e) => {
      const inputBuffer = e.inputBuffer.getChannelData(0);
      
      // Resample down to 16000Hz (e.g. from 48000Hz or 44100Hz)
      const resampledBuffer = downsample(inputBuffer, inputSampleRate, targetSampleRate);
      
      // Calculate RMS for noise cancellation floor detection (Root Mean Square of raw input buffer)
      let sum = 0;
      for (let i = 0; i < inputBuffer.length; i++) {
        sum += inputBuffer[i] * inputBuffer[i];
      }
      const rms = Math.sqrt(sum / inputBuffer.length);

      // Active Noise Gate / Software Noise Cancellation
      // If signal strength is below noise floor threshold, filter it out completely
      if (this.noiseGateEnabled && rms < this.noiseGateThreshold) {
        resampledBuffer.fill(0);
      }
      
      // Convert Float32 values to PCM16
      const pcm16Buffer = floatTo16BitPCM(resampledBuffer);
      
      // Convert binary buffer to Base64
      const base64Audio = arrayBufferToBase64(pcm16Buffer);

      // Call callback with Base64 audio chunk and calculated RMS
      if (base64Audio) {
        // Feed 0 amplitude if gated, so the visual waveforms properly flatten in real-time
        const reportRms = (this.noiseGateEnabled && rms < this.noiseGateThreshold) ? 0 : rms;
        this.onAudioChunk(base64Audio, reportRms);
      }
    };

    // 4. Connect nodes
    this.sourceNode.connect(this.processorNode);
    this.processorNode.connect(this.ctx.destination);
  }

  stop() {
    if (this.processorNode) {
      this.processorNode.disconnect();
      this.processorNode = null;
    }
    if (this.sourceNode) {
      this.sourceNode.disconnect();
      this.sourceNode = null;
    }
    if (this.stream) {
      this.stream.getTracks().forEach((track) => track.stop());
      this.stream = null;
    }
    if (this.ctx) {
      this.ctx.close().catch((e) => console.error("Error closing recording AudioContext:", e));
      this.ctx = null;
    }
  }
}
