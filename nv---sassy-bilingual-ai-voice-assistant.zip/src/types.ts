export type ConversationState = 'disconnected' | 'connecting' | 'idle' | 'listening' | 'speaking' | 'error';

export interface ActionLog {
  id: string;
  name: string; // "openWebsite" or "executeLocalCommand"
  url?: string;
  siteName?: string;
  action?: string;
  command?: string;
  friendlyDescription?: string;
  executed?: boolean;
  timestamp: Date;
}

export interface NVSubtitle {
  id: string;
  text: string;
  timestamp: Date;
}

export interface UserMemory {
  id: string;
  text: string;
  timestamp: Date;
}
