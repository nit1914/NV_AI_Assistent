import { useState, useEffect, useRef } from "react";
import { 
  motion, 
  AnimatePresence 
} from "motion/react";
import { 
  Power, 
  Sparkles, 
  ExternalLink, 
  Volume2, 
  VolumeX, 
  HelpCircle, 
  Terminal, 
  X, 
  Activity, 
  RotateCcw,
  Compass,
  Heart,
  Zap,
  Flame,
  MessageCircle,
  AlertOctagon,
  Cpu,
  Brain,
  Laptop,
  Trash2,
  Plus,
  Copy,
  Check
} from "lucide-react";
import { ConversationState, ActionLog, NVSubtitle, UserMemory } from "./types";
import { MicrophoneRecorder, ScheduledAudioPlayer } from "./utils/audio";

export default function App() {
  // App core states
  const [sessionState, setSessionState] = useState<ConversationState>("disconnected");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [muted, setMuted] = useState<boolean>(false);
  const [subtitles, setSubtitles] = useState<NVSubtitle[]>([]);
  const [actionLogs, setActionLogs] = useState<ActionLog[]>([]);
  const [blockedPopup, setBlockedPopup] = useState<{ url: string; siteName: string } | null>(null);

  // Memory & Laptop Control Companion states
  const [pairingCode] = useState<string>(() => {
    const existing = localStorage.getItem("nv_pairing_code");
    if (existing) return existing;
    // Generate a random readable 6-character code
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let newCode = "";
    for (let i = 0; i < 6; i++) {
       newCode += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    localStorage.setItem("nv_pairing_code", newCode);
    return newCode;
  });

  const [companionLinked, setCompanionLinked] = useState<boolean>(false);
  const [memories, setMemories] = useState<UserMemory[]>(() => {
    const saved = localStorage.getItem("nv_memories");
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed.map((m: any) => ({
            ...m,
            timestamp: new Date(m.timestamp || Date.now())
          }));
        }
      } catch (e) {
        console.error("Error reading saved memories:", e);
      }
    }
    return [
      { id: "init-1", text: "You are NV, and you love giving sassy Hinglish answers to user.", timestamp: new Date() },
      { id: "init-2", text: "User likes to be called 'boss' or 'jaan'.", timestamp: new Date() },
      { id: "init-3", text: "User plays video games and designs code.", timestamp: new Date() }
    ];
  });

  const addManualMemory = (text: string) => {
    if (!text.trim()) return;
    const newMem: UserMemory = {
      id: Math.random().toString(),
      text: text.trim(),
      timestamp: new Date()
    };
    const updated = [newMem, ...memories];
    setMemories(updated);
    localStorage.setItem("nv_memories", JSON.stringify(updated));
  };

  const deleteMemory = (id: string) => {
    const updated = memories.filter(m => m.id !== id);
    setMemories(updated);
    localStorage.setItem("nv_memories", JSON.stringify(updated));
  };
  
  // Custom sidebar/drawers toggles
  const [showLogs, setShowLogs] = useState<boolean>(false);
  const [showHelp, setShowHelp] = useState<boolean>(false);
  const [showMemory, setShowMemory] = useState<boolean>(false);
  const [showDevice, setShowDevice] = useState<boolean>(false);
  const [selectedShell, setSelectedShell] = useState<"powershell" | "cmd" | "bash">("powershell");

  // Advanced Acoustic & Noise Cancellation (ANC) Settings states
  const [showAcoustics, setShowAcoustics] = useState<boolean>(false);
  const [noiseGateEnabled, setNoiseGateEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem("nv_noise_gate_enabled");
    return saved !== null ? saved === "true" : true;
  });
  const [noiseGateThreshold, setNoiseGateThreshold] = useState<number>(() => {
    const saved = localStorage.getItem("nv_noise_gate_threshold");
    return saved !== null ? parseFloat(saved) : 0.015;
  });
  const [hardwareNoiseCancellation, setHardwareNoiseCancellation] = useState<boolean>(() => {
    const saved = localStorage.getItem("nv_hw_noise_cancellation");
    return saved !== null ? saved === "true" : true;
  });
  const [hardwareEchoCancellation, setHardwareEchoCancellation] = useState<boolean>(() => {
    const saved = localStorage.getItem("nv_hw_echo_cancellation");
    return saved !== null ? saved === "true" : true;
  });
  const [hardwareAutoGainControl, setHardwareAutoGainControl] = useState<boolean>(() => {
    const saved = localStorage.getItem("nv_hw_auto_gain");
    return saved !== null ? saved === "true" : true;
  });

  // Hot apply real-time modifications to active recorder instances
  useEffect(() => {
    if (recorderRef.current) {
      recorderRef.current.noiseGateEnabled = noiseGateEnabled;
    }
    localStorage.setItem("nv_noise_gate_enabled", String(noiseGateEnabled));
  }, [noiseGateEnabled]);

  useEffect(() => {
    if (recorderRef.current) {
      recorderRef.current.noiseGateThreshold = noiseGateThreshold;
    }
    localStorage.setItem("nv_noise_gate_threshold", String(noiseGateThreshold));
  }, [noiseGateThreshold]);

  useEffect(() => {
    if (recorderRef.current) {
      recorderRef.current.browserNoiseSuppression = hardwareNoiseCancellation;
    }
    localStorage.setItem("nv_hw_noise_cancellation", String(hardwareNoiseCancellation));
  }, [hardwareNoiseCancellation]);

  useEffect(() => {
    if (recorderRef.current) {
      recorderRef.current.browserEchoCancellation = hardwareEchoCancellation;
    }
    localStorage.setItem("nv_hw_echo_cancellation", String(hardwareEchoCancellation));
  }, [hardwareEchoCancellation]);

  useEffect(() => {
    if (recorderRef.current) {
      recorderRef.current.browserAutoGainControl = hardwareAutoGainControl;
    }
    localStorage.setItem("nv_hw_auto_gain", String(hardwareAutoGainControl));
  }, [hardwareAutoGainControl]);

  // References for Web Audio & WS connection
  const wsRef = useRef<WebSocket | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const recorderRef = useRef<MicrophoneRecorder | null>(null);
  const playerRef = useRef<ScheduledAudioPlayer | null>(null);

  // Animation visualizer rendering references
  const [speakingAmplitude, setSpeakingAmplitude] = useState<number>(0);
  const [listeningAmplitude, setListeningAmplitude] = useState<number>(0);
  const frequencyDataArrayRef = useRef<Uint8Array | null>(null);
  const animationFrameRef = useRef<number | null>(null);

  // Auto scroll references
  const transcriptEndRef = useRef<HTMLDivElement | null>(null);
  const actionsEndRef = useRef<HTMLDivElement | null>(null);

  // List of pre-recorded greeting headers or ideas to talk about in Hinglish style
  const SUGGESTED_PROMPTS = [
    "Tell me I look handsome today, yaar!",
    "Open YouTube with cute dog videos or Bollywood hits",
    "Explain quantum physics in a spicy masala way",
    "What's your absolute favorite Bollywood movie?",
    "Tease me about my engineering or IT job!",
  ];

  // Helper values for simulated/real visualizer bars to look extremely realistic
  const [pulseWave, setPulseWave] = useState<number[]>([4, 8, 5, 10, 12, 6, 4, 7, 9, 5]);

  // Sassy judgment phrases depending on status
  const getSubTitleJudgment = () => {
    switch(sessionState) {
      case "disconnected":
        return "NV is offline. Tap to connect, darling!";
      case "connecting":
        return "NV is syncing your voice matrix...";
      case "idle":
        return "NV is listening with a playful smirk...";
      case "listening":
        return "Aap bolo, main sun rahi hoon... let it be interesting";
      case "speaking":
        return "Sassy Hinglish vocal response is live!";
      case "error":
        return "Vibe check crashed! Telemetry error.";
      default:
        return "Analyzing current vibe...";
    }
  };

  // Initialize and run visualization loops when states change
  useEffect(() => {
    if (sessionState === "disconnected") {
      setSpeakingAmplitude(0);
      setListeningAmplitude(0);
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      return;
    }

    const updateVisualizers = () => {
      let activeAnalyser: AnalyserNode | null = null;

      if (sessionState === "speaking" && playerRef.current?.analyserNode) {
        activeAnalyser = playerRef.current.analyserNode;
      } else if (recorderRef.current?.analyserNode) {
        activeAnalyser = recorderRef.current.analyserNode;
      }

      if (activeAnalyser) {
        const bufferLength = activeAnalyser.frequencyBinCount;
        if (!frequencyDataArrayRef.current || frequencyDataArrayRef.current.length !== bufferLength) {
          frequencyDataArrayRef.current = new Uint8Array(bufferLength);
        }
        
        const dataArray = frequencyDataArrayRef.current;
        activeAnalyser.getByteFrequencyData(dataArray);

        // Compute average amplitude of low-to-mid frequencies where voice lives
        let sum = 0;
        const cutoff = Math.min(bufferLength, 32); // Focus on primary vocals
        for (let i = 0; i < cutoff; i++) {
          sum += dataArray[i];
        }
        const avg = sum / cutoff;
        const normalized = Math.min(1.5, avg / 70); // Normalize for scale factor

        // Build a dynamic state-derived bouncing array of heights for the visualizer equalizer
        const newWave = [];
        for (let i = 0; i < 12; i++) {
          const rawBin = dataArray[Math.floor(i * (bufferLength / 18))] || 0;
          const height = Math.max(4, Math.min(48, Math.round((rawBin / 255) * 44)));
          newWave.push(height);
        }
        setPulseWave(newWave);

        if (sessionState === "speaking") {
          setSpeakingAmplitude(normalized);
          setListeningAmplitude(0);
        } else {
          setListeningAmplitude(normalized);
          setSpeakingAmplitude(0);
        }
      } else {
        // Decay amplitudes gracefully
        setSpeakingAmplitude((v) => Math.max(0, v * 0.85));
        setListeningAmplitude((v) => Math.max(0, v * 0.85));
        
        // Decay visual waves with slight random idle pulses
        setPulseWave((prev) => 
          prev.map((h) => Math.max(4, Math.round(h * 0.85) + (Math.random() > 0.7 ? 1 : 0)))
        );
      }

      animationFrameRef.current = requestAnimationFrame(updateVisualizers);
    };

    updateVisualizers();

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [sessionState]);

  // Clean up all resources upon unmounting
  useEffect(() => {
    return () => {
      disconnectSession();
    };
  }, []);

  // Set up auto-scrolling for dynamic content rails
  useEffect(() => {
    transcriptEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [subtitles]);

  useEffect(() => {
    actionsEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [actionLogs]);

  // Main connect action
  const connectSession = async () => {
    try {
      setErrorMessage(null);
      setSessionState("connecting");

      // 1. Initialize master client-side AudioContext
      if (!audioContextRef.current) {
        audioContextRef.current = new AudioContext();
      }
      const audioCtx = audioContextRef.current;
      if (audioCtx.state === "suspended") {
        await audioCtx.resume();
      }

      // 2. Build local/production secure WebSocket url passing user memories and sync pairing controls
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const queryParams = `?code=${pairingCode}&memories=${encodeURIComponent(JSON.stringify(memories))}`;
      const wsUrl = `${protocol}//${window.location.host}/api/live-ws${queryParams}`;
      console.log("Connecting to NV bridge WS at", wsUrl);

      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      // 3. WS Open Handshake
      ws.onopen = () => {
        console.log("WebSocket bridge opened, waiting for Gemini configuration...");
      };

      // 4. Handle incoming messages from Gemini via bridge
      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);

          if (data.type === "status" && data.state === "connected") {
            // Server successfully launched the Gemini Live API!
            initializeSpeechSystems(audioCtx, ws);
          } else if (data.type === "audio") {
            // Incoming speaker bytes from NV
            if (!muted && playerRef.current) {
              playerRef.current.playChunk(data.audio);
            }
          } else if (data.type === "save_memory") {
            // NV learned a new personal preference or name fact
            const cleanText = data.text.trim();
            setMemories((prev) => {
              if (prev.some(m => m.text.toLowerCase() === cleanText.toLowerCase())) {
                return prev;
              }
              const updated = [{ id: Math.random().toString(), text: cleanText, timestamp: new Date() }, ...prev];
              localStorage.setItem("nv_memories", JSON.stringify(updated));
              return updated;
            });
          } else if (data.type === "companion_status") {
            // Background daemon laptop status linked change
            setCompanionLinked(data.status === "connected");
          } else if (data.type === "transcript") {
            // Real-time subtitle translation
            const textContent = data.text;
            setSubtitles((prev) => {
              const lastSubtitle = prev[prev.length - 1];
              // If the text arrives in incremental chunks within 2 seconds, merge it, otherwise append!
              if (lastSubtitle && Date.now() - lastSubtitle.timestamp.getTime() < 2500) {
                return [
                  ...prev.slice(0, -1),
                  { ...lastSubtitle, text: `${lastSubtitle.text} ${textContent}` }
                ];
              } else {
                return [...prev, { id: Math.random().toString(), text: textContent, timestamp: new Date() }];
              }
            });
          } else if (data.type === "interrupted") {
            // User interrupted NV's speech! Immediately silence active audio players
            console.log("Gemini triggered user interruption. Silencing NV.");
            if (playerRef.current) {
              playerRef.current.stop();
            }
          } else if (data.type === "action" && data.name === "openWebsite") {
            // Function call executed
            const newLog: ActionLog = {
              id: Math.random().toString(),
              name: "openWebsite",
              url: data.url,
              siteName: data.siteName,
              timestamp: new Date()
            };
            setActionLogs((prev) => [newLog, ...prev]);
            
            // Try of auto opening, standard browsers might block due to async trigger, 
            // but we provide polished link card controls in case of blocking!
            try {
              const newWin = window.open(data.url, "_blank");
              if (!newWin || newWin.closed || typeof newWin.closed === "undefined") {
                console.warn("Auto open returned null or was blocked");
                setBlockedPopup({ url: data.url, siteName: data.siteName });
              } else {
                setBlockedPopup(null); // Clear previous if successful
              }
            } catch (err) {
              console.warn("Auto open blocked by browser popup blocker", err);
              setBlockedPopup({ url: data.url, siteName: data.siteName });
            }
          } else if (data.type === "action" && data.name === "executeLocalCommand") {
            // Laptop control executed through pairing bridge!
            const newLog: ActionLog = {
              id: Math.random().toString(),
              name: "executeLocalCommand",
              action: data.action,
              command: data.command,
              friendlyDescription: data.friendlyDescription,
              executed: data.executed,
              timestamp: new Date()
            };
            setActionLogs((prev) => [newLog, ...prev]);
          } else if (data.type === "error") {
            // Fatal Gemini or environment error
            setErrorMessage(data.message);
            disconnectSession();
          }
        } catch (err) {
          console.error("Error reading WebSocket payload:", err);
        }
      };

      ws.onerror = (e) => {
        console.error("WebSocket socket error:", e);
        setErrorMessage("Failed to establish a network connection to our voice bridge server.");
        disconnectSession();
      };

      ws.onclose = () => {
        console.log("WebSocket connection closed.");
        setSessionState((s) => s === "connecting" || s === "error" ? s : "disconnected");
      };

    } catch (err: any) {
      console.error("Error connecting NV session:", err);
      setErrorMessage(err?.message || "Could not spin up audio hardware devices.");
      setSessionState("error");
    }
  };

  // Setup actual recording and playback instances once socket opens successfully
  const initializeSpeechSystems = async (audioCtx: AudioContext, ws: WebSocket) => {
    try {
      // Create Player
      const player = new ScheduledAudioPlayer((isSpeaking) => {
        setSessionState(isSpeaking ? "speaking" : "idle");
      });
      player.init(audioCtx);
      playerRef.current = player;

      // Create Recorder with active RMS volume-aware interruption control and active noise suppression configs
      const recorder = new MicrophoneRecorder((base64PCM16, rms) => {
        if (ws.readyState === WebSocket.OPEN) {
          // If NV is currently speaking and user speaks loud enough (RMS > 0.04), trigger local barge-in interruption!
          // This local trigger works alongside Google's native cloud VAD to deliver instant local response.
          // By thresholding at rms > 0.04, we ignore ambient background noise and prevent accidental cutting out!
          if (player.getIsPlaying() && rms > 0.04) {
            console.log("Local Voice Barge-in triggered. RMS level:", rms);
            player.stop();
            ws.send(JSON.stringify({ type: "interrupted" }));
          }
          ws.send(JSON.stringify({ audio: base64PCM16 }));
          
          // Only transition visual model modes when user actually starts vocalizing
          if (rms > 0.012) {
            setSessionState((current) => current === "speaking" ? current : "listening");
          } else {
            setSessionState((current) => current === "listening" ? "idle" : current);
          }
        }
      }, {
        noiseGateEnabled,
        noiseGateThreshold,
        browserNoiseSuppression: hardwareNoiseCancellation,
        browserEchoCancellation: hardwareEchoCancellation,
        browserAutoGainControl: hardwareAutoGainControl
      });
      await recorder.start();
      recorderRef.current = recorder;

      setSessionState("idle");
      // Add cute welcoming subtitle in bilingual Hinglish
      setSubtitles([
        {
          id: "welcome",
          text: "Namaste handsome! I'm NV. Tap my mic aur kuch mazedaar bolo. Don't make me wait! 😉",
          timestamp: new Date()
        }
      ]);
    } catch (err: any) {
      console.error("Mic access denied or failed:", err);
      setErrorMessage("Microphone access is required for Voice-to-Voice. Please enable microphone permissions in your browser.");
      setSessionState("error");
      disconnectSession();
    }
  };

  // Clean disconnections
  const disconnectSession = () => {
    if (recorderRef.current) {
      try { recorderRef.current.stop(); } catch(e) {}
      recorderRef.current = null;
    }
    if (playerRef.current) {
      try { playerRef.current.stop(); } catch(e) {}
      playerRef.current = null;
    }
    if (wsRef.current) {
      try { wsRef.current.close(); } catch(e) {}
      wsRef.current = null;
    }
    setSessionState("disconnected");
  };

  const handlePowerClick = () => {
    if (sessionState === "disconnected" || sessionState === "error") {
      connectSession();
    } else {
      disconnectSession();
    }
  };

  const toggleMute = () => {
    setMuted(!muted);
    if (!muted && playerRef.current) {
      playerRef.current.stop();
    }
  };

  const resetSubtitlesAndLogs = () => {
    setSubtitles([]);
    setActionLogs([]);
  };

  const currentGreeting = subtitles.length > 0 
    ? subtitles[subtitles.length - 1].text 
    : "Oh, look who decided to connect! Main toh kabse wait kar rahi thi. Try to make it interesting, haan?";

  return (
    <div className="relative min-h-screen bg-[#030304] text-white font-sans overflow-hidden flex flex-col selection:bg-rose-500/35 selection:text-white">
      
      {/* Dynamic atmospheric radial glow with Indian cultural accent (Saffron, Pomegranate Pink, Royal Indigo Gold) */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        {/* Deep background mesh overlay */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_30%,rgba(15,10,25,0.7),transparent_80%)]" />
        
        {/* Saffron/Orange ambient light top-left */}
        <motion.div 
          animate={{
            scale: [1, 1.15, 0.95, 1],
            x: [0, 20, -10, 0],
            y: [0, -15, 15, 0],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute top-[-10%] left-[-10%] w-[65%] h-[65%] bg-gradient-to-br from-[#FF9933] to-[#FF5E3A] opacity-[0.12] blur-[150px] rounded-full" 
        />
        
        {/* Vibrant Magenta/Pink ambient light bottom-right */}
        <motion.div 
          animate={{
            scale: [1, 0.9, 1.1, 1],
            x: [0, -15, 20, 0],
            y: [0, 20, -10, 0],
          }}
          transition={{
            duration: 18,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute bottom-[-15%] right-[-10%] w-[65%] h-[65%] bg-gradient-to-tl from-[#E0115F] to-[#8E2DE2] opacity-[0.15] blur-[155px] rounded-full" 
        />

        {/* Golden Spark Burst Top-Right for extra magical contrast */}
        <motion.div 
          animate={{
            opacity: [0.03, 0.07, 0.04, 0.03],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="absolute top-[15%] right-[10%] w-[35%] h-[35%] bg-[#FFD700] opacity-[0.05] blur-[120px] rounded-full" 
        />
      </div>

      {/* Top Header */}
      <header className="relative z-20 flex items-center justify-between px-8 py-6 border-b border-white/5 bg-black/20 backdrop-blur-md">
        <div className="flex items-center space-x-3.5">
          <span className="text-xl font-black tracking-tight text-white select-none flex items-center gap-1.5 bg-gradient-to-r from-white to-neutral-400 bg-clip-text text-transparent">
            NV <span className="text-xl not-sr-only text-white select-none filter drop-shadow">😊</span>
          </span>
          <div className="relative flex h-2.5 w-2.5">
            <span className={`absolute inline-flex h-full w-full rounded-full opacity-75 ${
              sessionState === "disconnected" ? "bg-white/20" :
              sessionState === "connecting" ? "animate-ping bg-cyan-400" :
              sessionState === "idle" ? "animate-ping bg-violet-400" :
              sessionState === "listening" ? "animate-ping bg-emerald-400" :
              "animate-ping bg-rose-400"
            }`} />
            <span className={`relative inline-flex rounded-full h-2.5 w-2.5 ${
              sessionState === "disconnected" ? "bg-white/20" :
              sessionState === "connecting" ? "bg-cyan-500" :
              sessionState === "idle" ? "bg-[#a259ff]" :
              sessionState === "listening" ? "bg-emerald-500" :
              "bg-[#ff2d55]"
            }`} />
          </div>
        </div>

        {/* Global Metadata metrics */}
        <div className="hidden md:flex space-x-6 text-[10px] tracking-[0.15em] font-semibold text-white/30 select-none">
          <span>STREAM: PCM16 16KHZ</span>
          <span>LATENCY: 34MS</span>
          <span>DEV PORT: 3000</span>
        </div>

        {/* Global Toolbar */}
        <div className="flex items-center space-x-2">
          {sessionState !== "disconnected" && (
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={toggleMute}
              className={`p-2 rounded-full border transition-all duration-300 ${
                muted 
                  ? "bg-rose-950/20 border-rose-500/30 text-rose-400" 
                  : "bg-white/5 border-white/10 text-white/60 hover:text-white hover:bg-white/10"
              }`}
              title={muted ? "Unmute voice responses" : "Mute voice responses"}
            >
              {muted ? <VolumeX size={14} /> : <Volume2 size={14} />}
            </motion.button>
          )}

          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => {
              setShowMemory(!showMemory);
              setShowLogs(false);
              setShowHelp(false);
              setShowDevice(false);
              setShowAcoustics(false);
            }}
            className={`p-2 rounded-full border transition-all duration-300 relative ${
              showMemory 
                ? "bg-emerald-950/20 border-emerald-500/30 text-emerald-400" 
                : "bg-white/5 border-white/10 text-white/60 hover:text-white hover:bg-white/10"
            }`}
            title="NV's Memory Core"
          >
            <Brain size={14} />
            {memories.length > 0 && (
              <span className="absolute top-1 right-1 h-1.5 w-1.5 rounded-full bg-emerald-400" />
            )}
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => {
              setShowDevice(!showDevice);
              setShowLogs(false);
              setShowHelp(false);
              setShowMemory(false);
              setShowAcoustics(false);
            }}
            className={`p-2 rounded-full border transition-all duration-300 relative ${
              showDevice 
                ? "bg-cyan-950/20 border-cyan-500/30 text-cyan-450" 
                : "bg-white/5 border-white/10 text-white/60 hover:text-white hover:bg-white/10"
            }`}
            title="Laptop Sync Daemon Control"
          >
            <Laptop size={14} />
            <span className={`absolute top-1 right-1 h-1.5 w-1.5 rounded-full ${
              companionLinked ? "bg-emerald-500 animate-pulse" : "bg-cyan-500"
            }`} />
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => {
              setShowAcoustics(!showAcoustics);
              setShowMemory(false);
              setShowLogs(false);
              setShowHelp(false);
              setShowDevice(false);
            }}
            className={`p-2 rounded-full border transition-all duration-300 relative ${
              showAcoustics 
                ? "bg-[#ff2d55]/20 border-[#ff2d55]/30 text-[#ff2d55]" 
                : "bg-white/5 border-white/10 text-white/60 hover:text-white hover:bg-white/10"
            }`}
            title="Noise Cancellation & Acoustics"
          >
            <Activity size={14} className={noiseGateEnabled ? "animate-pulse" : ""} />
            {noiseGateEnabled && (
              <span className="absolute top-1 right-1 h-1.5 w-1.5 rounded-full bg-[#ff2d55]" />
            )}
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => {
              setShowLogs(!showLogs);
              setShowHelp(false);
              setShowMemory(false);
              setShowDevice(false);
              setShowAcoustics(false);
            }}
            className={`p-2 rounded-full border transition-all duration-300 relative ${
              showLogs 
                ? "bg-violet-950/20 border-violet-500/30 text-violet-450" 
                : "bg-white/5 border-white/10 text-white/60 hover:text-white hover:bg-white/10"
            }`}
            title="Action platforms logs"
          >
            <Compass size={14} />
            {actionLogs.length > 0 && (
              <span className="absolute top-1 right-1 h-1.5 w-1.5 rounded-full bg-[#ff2d55]" />
            )}
          </motion.button>

          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={() => {
              setShowHelp(!showHelp);
              setShowLogs(false);
              setShowMemory(false);
              setShowDevice(false);
              setShowAcoustics(false);
            }}
            className={`p-2 rounded-full border transition-all duration-300 ${
              showHelp 
                ? "bg-indigo-950/20 border-indigo-500/30 text-indigo-400" 
                : "bg-white/5 border-white/10 text-white/60 hover:text-white hover:bg-white/10"
            }`}
            title="Help & Ideas"
          >
            <HelpCircle size={14} />
          </motion.button>
        </div>
      </header>

      {/* Main Container Grid */}
      <main className="flex-1 flex flex-col md:flex-row max-w-7xl w-full mx-auto relative z-10 p-6 gap-6 overflow-hidden">
        
        {/* Left Interactive Column (Main Minimal stage) */}
        <section className="flex-1 flex flex-col items-center justify-between min-h-[55vh] relative p-6 md:p-10 bg-black/20 backdrop-blur-md border border-white/5 rounded-3xl overflow-hidden shadow-2xl">
          
          <div className="w-full flex justify-between text-white/40 text-[10px] font-mono tracking-[0.1em] uppercase select-none">
            <span className="text-white hover:text-cyan-300 transition-colors font-bold flex items-center gap-1 cursor-pointer">NV 😊</span>
            <span>CORE VOICE INTERFACE</span>
          </div>

          {/* MAIN CONCENTRIC DYNAMIC ORB (THE CORE INTERFACE) */}
          <div className="my-auto relative flex items-center justify-center">
            
            {/* Real-time background glowing halo rings */}
            <AnimatePresence>
              {sessionState !== "disconnected" && (
                <>
                  {/* Outer Voice Wave Blur 1 */}
                  <motion.div 
                    animate={{
                      scale: sessionState === "speaking" 
                        ? 1.15 + speakingAmplitude * 0.8 
                        : sessionState === "listening" 
                        ? 1.05 + listeningAmplitude * 0.5 
                        : [1.0, 1.05, 1.0],
                      opacity: sessionState === "speaking" 
                        ? 0.18 + speakingAmplitude * 0.2 
                        : sessionState === "listening" 
                        ? 0.2 + listeningAmplitude * 0.2 
                        : 0.05
                    }}
                    transition={{
                      scale: (sessionState === "speaking" || sessionState === "listening")
                        ? { type: "spring", stiffness: 100, damping: 12 }
                        : { repeat: Infinity, duration: 4, ease: "easeInOut" },
                      opacity: { duration: 0.1 }
                    }}
                    className={`absolute inset-0 rounded-full blur-[50px] transition-colors duration-500 ${
                      sessionState === "connecting" ? "bg-cyan-500" :
                      sessionState === "listening" ? "bg-emerald-500" :
                      sessionState === "speaking" ? "bg-[#ff2d55]" :
                      "bg-[#a259ff]"
                    }`}
                    style={{ width: "260px", height: "260px" }}
                  />
                </>
              )}
            </AnimatePresence>

            {/* Central Circle Mesh Wrapper */}
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handlePowerClick}
              className="relative z-10 p-1.5 rounded-full cursor-pointer transition-colors duration-300"
            >
              {/* Central Concentric Rings extracted from Clean Minimalism design guidelines */}
              {/* Outer transparent ring: w-64, h-64, bg-black/40 backdrop-blur-xl border border-white/10 */}
              <div className="w-64 h-64 rounded-full border border-white/10 flex items-center justify-center bg-black/30 backdrop-blur-xl shadow-2xl transition-all duration-500 hover:border-white/20">
                {/* Middle border: w-48, h-48, border-[#ff2d55]/30 */}
                <div className={`w-48 h-48 rounded-full border flex items-center justify-center transition-all duration-500 ${
                  sessionState === "listening" ? "border-emerald-500/40 shadow-[0_0_30px_rgba(16,185,129,0.2)]" :
                  sessionState === "speaking" ? "border-[#ff2d55]/40 shadow-[0_0_40px_rgba(255,45,85,0.25)]" :
                  sessionState === "idle" ? "border-[#a259ff]/30 shadow-[0_0_30px_rgba(162,89,255,0.15)]" :
                  "border-white/10 shadow-none"
                }`}>
                  
                  {/* Central gradient orb: w-32, h-32 */}
                  <div className={`w-32 h-32 rounded-full flex flex-col items-center justify-center transition-all duration-500 shadow-xl ${
                    sessionState === "disconnected" 
                      ? "bg-white/5 border border-white/10 hover:bg-white/10" 
                      : "bg-gradient-to-tr from-[#ff2d55] to-[#a259ff] shadow-[0_0_50px_rgba(162,89,255,0.35)]"
                  }`}>
                    
                    {/* Visualizer reactive rings or state icons inside orb */}
                    <AnimatePresence mode="wait">
                      {sessionState === "disconnected" ? (
                        <motion.div 
                          key="dis"
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          className="flex flex-col items-center space-y-1.5 text-white/60 hover:text-white transition-colors duration-300"
                        >
                          <Power size={24} className="text-white/80" />
                          <span className="text-[8px] tracking-[0.2em] font-bold uppercase text-white/50">CONNECT</span>
                        </motion.div>
                      ) : (
                        <motion.div
                          key="act"
                          initial={{ scale: 0.9, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          className="flex flex-col items-center relative"
                        >
                          {sessionState === "connecting" ? (
                            <Activity size={28} className="text-white animate-pulse" />
                          ) : sessionState === "listening" ? (
                            <Activity size={28} className="text-white animate-bounce" />
                          ) : sessionState === "speaking" ? (
                            <Sparkles size={28} className="text-white animate-pulse" />
                          ) : (
                            <Heart size={26} className="text-white fill-white/20" />
                          )}
                        </motion.div>
                      )}
                    </AnimatePresence>

                  </div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* REAL-TIME RESPONSIVE TEXT OVERLAY (CLEAN MINIMALIST QUOTE DESIGN) */}
          <div className="w-full max-w-2xl text-center space-y-4">
            <div className="min-h-[6.5rem] flex flex-col justify-center items-center">
              <AnimatePresence mode="wait">
                <motion.h1
                  key={currentGreeting}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.4 }}
                  className="text-2xl md:text-3.5xl font-light tracking-tight text-white/90 italic font-serif leading-relaxed max-h-[140px] overflow-y-auto px-4 scroller custom-scrollbar"
                >
                  "{currentGreeting}"
                </motion.h1>
              </AnimatePresence>
            </div>

            {/* Sassy indicator aligned with status state */}
            <p className="text-[10px] tracking-[0.4em] font-extrabold text-[#ff2d55] uppercase transition-all duration-300">
              {getSubTitleJudgment()}
            </p>
          </div>

          {/* User message status panel */}
          {blockedPopup && (
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 10 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="mt-4 p-4 border border-cyan-500/20 bg-cyan-950/20 rounded-2xl max-w-lg w-full flex flex-col gap-3 select-none shadow-xl backdrop-blur-md relative overflow-hidden text-left"
            >
              <div className="absolute top-2 right-2">
                <button 
                  onClick={() => setBlockedPopup(null)}
                  className="p-1 px-2 text-white/40 hover:text-white rounded-lg hover:bg-white/5 transition-colors text-[10px] font-mono"
                >
                  Dismiss [x]
                </button>
              </div>

              <div className="flex gap-3">
                <div className="p-2 bg-cyan-500/10 rounded-xl text-cyan-400 self-start shrink-0 animate-pulse">
                  <Sparkles size={16} />
                </div>
                <div className="space-y-1.5 pr-12 flex-1">
                  <h4 className="text-xs font-bold text-cyan-400 uppercase tracking-wider">
                    Portal Run Authorization Required
                  </h4>
                  <p className="text-[11px] text-white/70 leading-relaxed">
                    NV wants to open <strong>{blockedPopup.siteName}</strong>. Browsers like Brave or Chrome intercept popups from background voice cues. Go ahead and grant direct portal permission to run the site:
                  </p>
                  {companionLinked && (
                    <div className="text-[10px] text-emerald-400 font-semibold bg-emerald-500/10 rounded-xl p-2.5 border border-emerald-500/10 mt-1 flex items-center gap-1.5">
                      <span className="flex h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      <span>Active Laptop Companion launched YouTube/URL natively on your system!</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-2">
                <a 
                  href={blockedPopup.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  onClick={() => setBlockedPopup(null)}
                  className="flex-1 py-2.5 px-3 bg-gradient-to-r from-cyan-400 to-purple-400 hover:brightness-110 text-black font-black text-xs rounded-xl transition-all text-center flex items-center justify-center gap-1.5 shadow-lg"
                >
                  <ExternalLink size={12} />
                  <span>👉 Grant Permission & Run Website</span>
                </a>
                <button
                  onClick={() => {
                    alert("HOW TO SECURELY UNBLOCK BRAVE OR CHROME SHIELDS FOR NV:\n\n1. Look at the right-side of your browser URL search bar (right near the star favorite button). You will notice an icon resembling a window with a tiny red 'x' or shield restriction icon.\n2. Click that blocked icon and choose 'Always allow popups and redirects from this origin'.\n3. Click 'Done' and prompt NV again. It will now automatic-open URLs seamlessly!");
                  }}
                  className="py-2.5 px-3 border border-[#a259ff]/30 hover:border-[#a259ff]/50 bg-white/5 hover:bg-white/10 text-white hover:text-cyan-300 text-[10px] rounded-xl transition-all text-center font-mono font-bold uppercase tracking-wider"
                >
                  Unblock Shields Guide 🛡️
                </button>
              </div>
            </motion.div>
          )}

          {errorMessage && (
            <div className="mt-2 px-4 py-2.5 border border-rose-500/20 bg-rose-950/20 text-rose-400 rounded-full text-xs flex items-center gap-2 max-w-lg w-full justify-between select-none shadow-lg backdrop-blur-md">
              <span className="flex-1 text-center font-mono font-medium">{errorMessage}</span>
              <button 
                onClick={() => setErrorMessage(null)}
                className="p-1 rounded-full hover:bg-rose-500/10 text-rose-500"
              >
                <X size={12} />
              </button>
            </div>
          )}
        </section>

        {/* Right Info / Action Sidebar (Clean minimalist drawer styling) */}
        <AnimatePresence>
          {showAcoustics && (
            <motion.aside
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 50 }}
              transition={{ duration: 0.25 }}
              className="w-full md:w-[340px] flex flex-col border border-white/5 bg-black/40 backdrop-blur-xl rounded-3xl p-6 overflow-hidden shadow-2xl relative z-20"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-white/5 pb-4 mb-4 select-none">
                <div className="flex items-center space-x-2 text-[#ff2d55]">
                  <Activity size={16} className="animate-pulse" />
                  <span className="text-[10px] uppercase tracking-[0.2em] font-extrabold text-white/60">Acoustic Guard</span>
                </div>
                <button 
                  onClick={() => setShowAcoustics(false)} 
                  className="p-1 text-white/40 hover:text-white rounded-full hover:bg-white/5 transition-colors"
                >
                  <X size={14} />
                </button>
              </div>

              {/* Status banner */}
              <div className="mb-4 select-none">
                <div className={`flex items-center gap-2.5 p-3.5 rounded-2xl border transition-all ${
                  noiseGateEnabled 
                    ? "bg-[#ff2d55]/10 border-[#ff2d55]/20 text-[#ff2d55]" 
                    : "bg-white/5 border-white/10 text-white/40"
                }`}>
                  <div className="relative flex h-3 w-3 shrink-0">
                    {noiseGateEnabled && (
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#ff2d55]/50 opacity-75" />
                    )}
                    <span className={`relative inline-flex rounded-full h-3 w-3 ${noiseGateEnabled ? "bg-[#ff2d55]" : "bg-white/30"}`} />
                  </div>
                  <div>
                    <h4 className="text-[10px] font-bold uppercase tracking-wider">
                      {noiseGateEnabled ? "Audio Filter Active" : "Filter Disabled"}
                    </h4>
                    <p className="text-[9px] text-white/50 leading-relaxed">
                      {noiseGateEnabled 
                        ? "Blocking ambient hums, vents and click noises!" 
                        : "Passing raw microphone sound directly."}
                    </p>
                  </div>
                </div>
              </div>

              {/* Controls Scroll Area */}
              <div className="flex-1 overflow-y-auto space-y-4 pr-1 scroller custom-scrollbar select-none">
                
                {/* 1. Software Noise Gate */}
                <div className="space-y-2 bg-white/3 p-3.5 rounded-2xl border border-white/5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-white/80 uppercase">Vocal Noise Gate</span>
                    <button
                      onClick={() => setNoiseGateEnabled(!noiseGateEnabled)}
                      className={`text-[9px] px-2.5 py-1 rounded-lg font-mono font-bold uppercase tracking-wider transition-all ${
                        noiseGateEnabled 
                          ? "bg-[#ff2d55]/20 text-[#ff2d55] border border-[#ff2d55]/25" 
                          : "bg-white/5 text-white/40 border border-white/10"
                      }`}
                    >
                      {noiseGateEnabled ? "ON" : "OFF"}
                    </button>
                  </div>
                  <p className="text-[10px] text-white/50 leading-relaxed">
                    Instantly zeroes out mic signals if background rooms hum below your target threshold level.
                  </p>

                  {noiseGateEnabled && (
                    <div className="space-y-2 pt-2 border-t border-white/5">
                      <div className="flex justify-between items-center text-[10px] font-mono">
                        <span className="text-white/40">Gating Floor:</span>
                        <span className="text-cyan-400">{noiseGateThreshold.toFixed(4)} RMS</span>
                      </div>
                      <input 
                        type="range"
                        min="0.002"
                        max="0.08"
                        step="0.001"
                        value={noiseGateThreshold}
                        onChange={(e) => setNoiseGateThreshold(parseFloat(e.target.value))}
                        className="w-full accent-[#ff2d55] bg-white/10 h-1.5 rounded-lg appearance-none cursor-pointer"
                      />
                      
                      {/* Presets */}
                      <div className="flex gap-1.5 text-[8px] font-bold font-mono">
                        <button
                          onClick={() => setNoiseGateThreshold(0.005)}
                          className={`flex-1 py-1 rounded bg-white/5 hover:bg-white/10 text-center transition-all ${
                            noiseGateThreshold === 0.005 ? "text-cyan-300 border border-cyan-500/20 bg-cyan-950/20" : "text-white/40"
                          }`}
                        >
                          Quiet Room
                        </button>
                        <button
                          onClick={() => setNoiseGateThreshold(0.015)}
                          className={`flex-1 py-1 rounded bg-white/5 hover:bg-white/10 text-center transition-all ${
                            noiseGateThreshold === 0.015 ? "text-purple-300 border border-[#a259ff]/20 bg-[#a259ff]/20" : "text-white/40"
                          }`}
                        >
                          Normal Fan
                        </button>
                        <button
                          onClick={() => setNoiseGateThreshold(0.035)}
                          className={`flex-1 py-1 rounded bg-white/5 hover:bg-white/10 text-center transition-all ${
                            noiseGateThreshold === 0.035 ? "text-rose-450 border border-rose-500/20 bg-rose-950/20" : "text-white/40"
                          }`}
                        >
                          Noisy Street
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* 2. Hardware Browser DSP */}
                <div className="space-y-3 bg-white/3 p-3.5 rounded-2xl border border-white/5">
                  <h4 className="text-[10px] uppercase font-bold text-white/85 tracking-wider">Web Browser DSP DSP</h4>
                  <p className="text-[10px] text-white/50 leading-relaxed">
                    Enable standard browser digital signal parameters. Applies upon next manual restart.
                  </p>

                  <div className="space-y-1.5 pt-1">
                    {/* Echo */}
                    <label className="flex items-center justify-between cursor-pointer p-1.5 rounded-lg hover:bg-white/2 transition-colors">
                      <span className="text-[10px] text-white/70">Echo Cancellation</span>
                      <input 
                        type="checkbox"
                        checked={hardwareEchoCancellation}
                        onChange={(e) => setHardwareEchoCancellation(e.target.checked)}
                        className="rounded bg-black border-white/20 text-[#ff2d55] h-3.5 w-3.5 cursor-pointer accent-[#ff2d55]"
                      />
                    </label>

                    {/* Noise Supp */}
                    <label className="flex items-center justify-between cursor-pointer p-1.5 rounded-lg hover:bg-white/2 transition-colors">
                      <span className="text-[10px] text-white/70">Integrated Suppressor</span>
                      <input 
                        type="checkbox"
                        checked={hardwareNoiseCancellation}
                        onChange={(e) => setHardwareNoiseCancellation(e.target.checked)}
                        className="rounded bg-black border-white/20 text-[#ff2d55] h-3.5 w-3.5 cursor-pointer accent-[#ff2d55]"
                      />
                    </label>

                    {/* Auto Gain */}
                    <label className="flex items-center justify-between cursor-pointer p-1.5 rounded-lg hover:bg-white/2 transition-colors">
                      <span className="text-[10px] text-white/70">Auto Gain Control</span>
                      <input 
                        type="checkbox"
                        checked={hardwareAutoGainControl}
                        onChange={(e) => setHardwareAutoGainControl(e.target.checked)}
                        className="rounded bg-black border-white/20 text-[#ff2d55] h-3.5 w-3.5 cursor-pointer accent-[#ff2d55]"
                      />
                    </label>
                  </div>

                  {sessionState !== "disconnected" && (
                    <div className="p-2 bg-amber-500/10 border border-amber-500/15 rounded-xl text-[9px] text-amber-300 leading-normal font-medium">
                      ⚠️ Hardware edits apply on next speech reload!
                    </div>
                  )}
                </div>

                {/* 3. Realtime Status Metrics */}
                <div className="bg-black/40 p-3.5 rounded-2xl border border-white/5 space-y-2 text-[9px] font-mono text-white/50">
                  <div className="flex justify-between items-center text-white/30 border-b border-white/5 pb-1 select-none">
                    <span>Guard Telemetry</span>
                    <span className="text-cyan-400">Live</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Format:</span>
                    <span className="text-white">PCM16 16kHz</span>
                  </div>
                  <div className="flex justify-between">
                    <span>AI Gated status:</span>
                    <span className={noiseGateEnabled ? "text-emerald-400" : "text-amber-400"}>
                      {noiseGateEnabled ? "ACTIVE GATE" : "BYPASSED"}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>Floor VAD Thresh:</span>
                    <span className="text-[#ff2d55]">{noiseGateEnabled ? `${noiseGateThreshold.toFixed(3)}` : "N/A"}</span>
                  </div>
                </div>

              </div>
            </motion.aside>
          )}

          {showLogs && (
            <motion.aside
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 50 }}
              transition={{ duration: 0.25 }}
              className="w-full md:w-[340px] flex flex-col border border-white/5 bg-black/40 backdrop-blur-xl rounded-3xl p-6 overflow-hidden shadow-2xl relative z-20"
            >
              {/* Sidebar Header */}
              <div className="flex items-center justify-between border-b border-white/5 pb-4 mb-4 select-none">
                <div className="flex items-center space-x-2 text-violet-400">
                  <Compass size={16} />
                  <span className="text-[10px] uppercase tracking-[0.2em] font-extrabold text-white/60">NV Link Rail</span>
                </div>
                <button 
                  onClick={() => setShowLogs(false)} 
                  className="p-1 text-white/40 hover:text-white rounded-full hover:bg-white/5 transition-colors"
                >
                  <X size={14} />
                </button>
              </div>

              {/* Action content description */}
              <p className="text-white/40 text-xs mb-4 leading-relaxed select-none">
                NV opens requested web portals instantly. Use this manual terminal override if your browser's security blocks popup tabs.
              </p>

              {/* Actions History Loop */}
              <div className="flex-1 flex flex-col overflow-y-auto space-y-3.5 pr-2 custom-scrollbar select-none">
                {actionLogs.length > 0 ? (
                  actionLogs.map((log) => (
                    <motion.div
                      key={log.id}
                      initial={{ scale: 0.98, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="p-4 rounded-xl border border-white/10 bg-white/5 hover:border-white/20 hover:bg-white/10 transition-all duration-300 shadow-md group border-l-2 border-l-[#ff2d55]"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-mono text-[9px] text-rose-450 font-bold uppercase tracking-widest flex items-center gap-1">
                          <Terminal size={10} />
                          <span>Portal Triggered</span>
                        </span>
                        <span className="text-[9px] text-white/30 font-mono">
                          {log.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      
                      <h4 className="font-display font-medium text-xs text-white/90 mb-1 leading-snug">
                        {log.siteName}
                      </h4>
                      
                      <p className="text-[10px] text-white/40 truncate mb-2.5">
                        {log.url}
                      </p>

                      <a 
                        href={log.url} 
                        target="_blank" 
                        rel="noreferrer"
                        className="inline-flex items-center space-x-1 text-[11px] text-[#ff2d55] group-hover:text-rose-400 font-semibold border-b border-rose-500/10 group-hover:border-rose-500/30 pb-0.5 transition-all outline-none"
                      >
                        <span>Override redirect</span>
                        <ExternalLink size={9} />
                      </a>
                    </motion.div>
                  ))
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center text-center text-white/30 p-4 border border-dashed border-white/10 rounded-xl">
                    <Compass size={24} className="opacity-25 mb-1.5" />
                    <span className="text-[10px] font-mono tracking-wider">Awaiting voice-triggered links</span>
                  </div>
                )}
                <div ref={actionsEndRef} />
              </div>

              {/* Sidebar Action Button */}
              {actionLogs.length > 0 && (
                <button
                  onClick={resetSubtitlesAndLogs}
                  className="mt-4 w-full py-2 bg-white/5 hover:bg-white/10 text-white/60 hover:text-white border border-white/10 text-[10px] font-mono font-bold uppercase tracking-wider rounded-xl transition-all duration-300 flex items-center justify-center gap-1.5"
                >
                  <RotateCcw size={10} />
                  <span>Wipe Session Rails</span>
                </button>
              )}
            </motion.aside>
          )}
        </AnimatePresence>

        {/* Dynamic Memory Core Drawer */}
        <AnimatePresence>
          {showMemory && (
            <motion.aside
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 50 }}
              transition={{ duration: 0.25 }}
              className="w-full md:w-[340px] flex flex-col border border-white/5 bg-black/40 backdrop-blur-xl rounded-3xl p-6 overflow-hidden shadow-2xl relative z-20"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-white/5 pb-4 mb-4 select-none">
                <div className="flex items-center space-x-2 text-emerald-400">
                  <Brain size={16} />
                  <span className="text-[10px] uppercase tracking-[0.2em] font-extrabold text-white/60">Memory Vault</span>
                </div>
                <button 
                  onClick={() => setShowMemory(false)} 
                  className="p-1 text-white/40 hover:text-white rounded-full hover:bg-white/5 transition-colors"
                >
                  <X size={14} />
                </button>
              </div>

              <p className="text-white/40 text-[11px] mb-4 leading-relaxed select-none">
                NV stores long-term facts dynamically as you chat! To teach her fast parameters manually, add custom memory blocks here.
              </p>

              {/* Memory Form */}
              <div className="mb-4">
                <form 
                  onSubmit={(e) => {
                    e.preventDefault();
                    const form = e.currentTarget;
                    const input = form.elements.namedItem("memoryInput") as HTMLInputElement;
                    if (input && input.value.trim()) {
                      addManualMemory(input.value);
                      input.value = "";
                    }
                  }}
                  className="flex gap-2"
                >
                  <input 
                    name="memoryInput"
                    placeholder="E.g., My name is Sachin..."
                    maxLength={100}
                    className="flex-1 bg-white/5 hover:bg-white/10 focus:bg-white/10 text-white text-xs px-3 py-2.5 rounded-xl border border-white/10 focus:border-emerald-500/50 outline-none placeholder:text-white/20 transition-all font-sans"
                  />
                  <button 
                    type="submit"
                    className="p-2.5 bg-emerald-500 hover:bg-emerald-400 text-black rounded-xl transition-colors shrink-0 flex items-center justify-center"
                    title="Remember Fact"
                  >
                    <Plus size={14} />
                  </button>
                </form>
              </div>

              {/* Memory List Scroll Container */}
              <div className="flex-1 overflow-y-auto space-y-3 custom-scrollbar pr-1">
                {memories.length > 0 ? (
                  memories.map((mem) => (
                    <motion.div 
                      key={mem.id}
                      initial={{ scale: 0.98, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="p-3.5 rounded-xl border border-white/5 bg-white/2 hover:border-white/10 hover:bg-white/5 transition-all flex items-start justify-between gap-3 group"
                    >
                      <div className="space-y-1 overflow-hidden flex-1">
                        <p className="text-xs text-white/80 leading-snug break-words">
                          {mem.text}
                        </p>
                        <p className="text-[8px] text-white/20 font-mono">
                          Saved: {mem.timestamp.toLocaleDateString()} at {mem.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                      <button 
                        onClick={() => deleteMemory(mem.id)}
                        className="p-1 text-white/30 hover:text-rose-450 hover:bg-rose-500/10 rounded-lg transition-all shrink-0 self-center opacity-70 hover:opacity-100"
                        title="Evict fact"
                      >
                        <Trash2 size={11} />
                      </button>
                    </motion.div>
                  ))
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center text-center text-white/30 py-10 border border-dashed border-white/10 rounded-xl">
                    <Brain size={24} className="opacity-25 mb-1.5" />
                    <span className="text-[10px] font-mono tracking-wider">No memories saved yet</span>
                  </div>
                )}
              </div>
            </motion.aside>
          )}
        </AnimatePresence>

        {/* Laptop Remote Device Linked Controls Panel */}
        <AnimatePresence>
          {showDevice && (
            <motion.aside
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 50 }}
              transition={{ duration: 0.25 }}
              className="w-full md:w-[340px] flex flex-col border border-white/5 bg-black/40 backdrop-blur-xl rounded-3xl p-6 overflow-hidden shadow-2xl relative z-20"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-white/5 pb-4 mb-4 select-none">
                <div className="flex items-center space-x-2 text-cyan-400">
                  <Laptop size={16} />
                  <span className="text-[10px] uppercase tracking-[0.2em] font-extrabold text-white/60">Laptop Control</span>
                </div>
                <button 
                  onClick={() => setShowDevice(false)} 
                  className="p-1 text-white/40 hover:text-white rounded-full hover:bg-white/5 transition-colors"
                >
                  <X size={14} />
                </button>
              </div>

              {/* Linking Status Indicators */}
              <div className="mb-4">
                {companionLinked ? (
                  <div className="flex items-center gap-2.5 bg-emerald-500/10 border border-emerald-500/20 p-3.5 rounded-2xl">
                    <div className="relative flex h-3.5 w-3.5 shrink-0">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                      <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Device Online</h4>
                      <p className="text-[10px] text-white/45">Linked via Token: <span className="font-mono font-black text-rose-450">{pairingCode}</span></p>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-2.5 bg-cyan-500/10 border border-cyan-500/20 p-3.5 rounded-2xl">
                    <div className="h-3.5 w-3.5 bg-cyan-500 rounded-full animate-pulse" />
                    <div>
                      <h4 className="text-xs font-bold text-cyan-400 uppercase tracking-wider">Awaiting Link...</h4>
                      <p className="text-[10px] text-white/45">Ready Token: <span className="font-mono font-black text-white">{pairingCode}</span></p>
                    </div>
                  </div>
                )}
              </div>

              {/* Setup Flow Instructions */}
              <div className="flex-1 overflow-y-auto space-y-4 pr-1 scroller custom-scrollbar select-none">
                <div>
                  <h4 className="text-[9px] font-extrabold text-white/30 tracking-[0.25em] uppercase mb-1.5">HOW TO SET UP</h4>
                  <p className="text-xs text-white/60 leading-relaxed bg-white/2 p-3 outline outline-white/5 rounded-xl">
                    Open your Laptop's terminal and copy the commands to link your device. 
                    <span className="text-purple-300 font-bold block mt-1">💡 For PowerShell, do not use &&; use our formatted commands below!</span>
                  </p>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-[9px] font-extrabold text-[#a259ff] tracking-[0.25em] uppercase">TERMINAL SELECTOR</h4>
                  </div>
                  
                  {/* Shell Switcher Tabs */}
                  <div className="flex bg-white/5 p-1 rounded-xl gap-1.5 border border-white/5 text-[10px] font-bold select-none">
                    {(["powershell", "cmd", "bash"] as const).map((shell) => (
                      <button
                        key={shell}
                        type="button"
                        onClick={() => setSelectedShell(shell)}
                        className={`flex-1 py-1.5 rounded-lg transition-all text-center ${
                          selectedShell === shell
                            ? "bg-[#a259ff]/20 text-purple-300 border border-[#a259ff]/30"
                            : "text-white/40 hover:text-white hover:bg-white/5 border border-transparent"
                        }`}
                      >
                        {shell === "powershell" ? "PowerShell" : shell === "cmd" ? "CMD (Win)" : "macOS / Linux"}
                      </button>
                    ))}
                  </div>

                  {/* Step by Step Manual Grid */}
                  <div className="space-y-3 bg-white/5 p-3 rounded-2xl border border-white/5">
                    <h5 className="text-[10px] text-purple-300 font-bold uppercase tracking-wider">🐾 Step-by-Step Guide</h5>
                    
                    {/* Step 1 */}
                    <div className="space-y-1">
                      <div className="text-[10px] text-white/70 font-semibold flex justify-between items-center">
                        <span>1️⃣ Download Script File</span>
                        <button
                          onClick={() => {
                            const dlCmd = selectedShell === "powershell" 
                              ? `curl.exe -s "${window.location.protocol}//${window.location.host}/api/companion.py?code=${pairingCode}" -o nv_control.py`
                              : `curl -s "${window.location.protocol}//${window.location.host}/api/companion.py?code=${pairingCode}" -o nv_control.py`;
                            navigator.clipboard.writeText(dlCmd);
                            alert("Copied Step 1: Download command!");
                          }}
                          className="text-[9px] text-cyan-400 font-mono hover:underline"
                        >
                          Copy
                        </button>
                      </div>
                      <div className="bg-black/40 rounded-lg p-2 font-mono text-[9px] text-cyan-300 break-all select-all">
                        {selectedShell === "powershell" ? (
                          `curl.exe -s "${window.location.protocol}//${window.location.host}/api/companion.py?code=${pairingCode}" -o nv_control.py`
                        ) : (
                          `curl -s "${window.location.protocol}//${window.location.host}/api/companion.py?code=${pairingCode}" -o nv_control.py`
                        )}
                      </div>
                    </div>

                    {/* Step 2 */}
                    <div className="space-y-1">
                      <div className="text-[10px] text-white/70 font-semibold flex justify-between items-center">
                        <span>2️⃣ Install Dependency (Optional)</span>
                        <button
                          onClick={() => {
                            navigator.clipboard.writeText("pip install websocket-client");
                            alert("Copied Step 2: Install command!");
                          }}
                          className="text-[9px] text-cyan-400 font-mono hover:underline"
                        >
                          Copy
                        </button>
                      </div>
                      <div className="bg-black/40 rounded-lg p-2 font-mono text-[9px] text-cyan-300 break-all select-all">
                        pip install websocket-client
                      </div>
                    </div>

                    {/* Step 3 */}
                    <div className="space-y-1">
                      <div className="text-[10px] text-white/70 font-semibold flex justify-between items-center">
                        <span>3️⃣ Launch Companion Core</span>
                        <button
                          onClick={() => {
                            const runCmd = selectedShell === "bash" ? "python3 nv_control.py" : "python nv_control.py";
                            navigator.clipboard.writeText(runCmd);
                            alert("Copied Step 3: Launch command!");
                          }}
                          className="text-[9px] text-cyan-400 font-mono hover:underline"
                        >
                          Copy
                        </button>
                      </div>
                      <div className="bg-black/40 rounded-lg p-2 font-mono text-[9px] text-cyan-300 break-all select-all">
                        {selectedShell === "bash" ? "python3 nv_control.py" : "python nv_control.py"}
                      </div>
                    </div>
                  </div>

                  {/* Single Line Fast Pipeline Trigger */}
                  <div className="space-y-2">
                    <h5 className="text-[9px] font-extrabold text-[#a259ff] tracking-[0.25em] uppercase">⚡ OR RUN 1-LINE FAST PIPELINE:</h5>
                    <div className="bg-black/80 rounded-xl p-3 border border-white/10 font-mono text-[9px] text-cyan-300 relative group overflow-x-auto select-all max-h-24 leading-relaxed whitespace-normal break-all">
                      {selectedShell === "powershell" ? (
                        `curl.exe -s "${window.location.protocol}//${window.location.host}/api/companion.py?code=${pairingCode}" -o nv_control.py; python nv_control.py`
                      ) : selectedShell === "cmd" ? (
                        `curl -s "${window.location.protocol}//${window.location.host}/api/companion.py?code=${pairingCode}" -o nv_control.py && python nv_control.py`
                      ) : (
                        `curl -s "${window.location.protocol}//${window.location.host}/api/companion.py?code=${pairingCode}" -o nv_control.py && python3 nv_control.py`
                      )}
                    </div>
                    <button 
                      onClick={() => {
                        const host = window.location.host;
                        const protocol = window.location.protocol;
                        let curlcmd = "";
                        if (selectedShell === "powershell") {
                          curlcmd = `curl.exe -s "${protocol}//${host}/api/companion.py?code=${pairingCode}" -o nv_control.py; python nv_control.py`;
                        } else if (selectedShell === "cmd") {
                          curlcmd = `curl -s "${protocol}//${host}/api/companion.py?code=${pairingCode}" -o nv_control.py && python nv_control.py`;
                        } else {
                          curlcmd = `curl -s "${protocol}//${host}/api/companion.py?code=${pairingCode}" -o nv_control.py && python3 nv_control.py`;
                        }
                        navigator.clipboard.writeText(curlcmd);
                        alert(`Copied ${selectedShell === "powershell" ? "PowerShell" : selectedShell === "cmd" ? "Command Prompt" : "macOS / Linux"} setup pipeline command!`);
                      }}
                      className="w-full py-2.5 bg-[#a259ff]/10 hover:bg-[#a259ff]/20 text-[#a259ff] hover:text-purple-300 border border-[#a259ff]/20 rounded-xl text-[10px] font-mono font-bold uppercase tracking-wider transition-all flex items-center justify-center gap-1.5"
                    >
                      <Copy size={11} />
                      <span>Copy 1-Line Pipeline</span>
                    </button>
                  </div>
                </div>

                <div>
                  <h4 className="text-[9px] font-extrabold text-white/30 tracking-[0.25em] uppercase mb-1.5">DAEMON CAPABILITIES</h4>
                  <ul className="text-[10px] text-white/40 space-y-2 leading-relaxed">
                    <li className="flex items-start gap-1.5">
                      <span className="text-[#a259ff] mt-0.5">✔</span>
                      <span><strong>Volume Modulation</strong>: NV increases, decreases, or mutes Mac/Windows volume on command!</span>
                    </li>
                    <li className="flex items-start gap-1.5">
                      <span className="text-[#a259ff] mt-0.5">✔</span>
                      <span><strong>Instant Sleep Link</strong>: Sassy voice locks or sleeps your laptop instantly (LockWorkStation/Sleep modes).</span>
                    </li>
                    <li className="flex items-start gap-1.5">
                      <span className="text-[#a259ff] mt-0.5">✔</span>
                      <span><strong>App Launch Gate</strong>: Opens local programs like Spotify, Notepad, Calculator, Safari, Chrome.</span>
                    </li>
                  </ul>
                </div>
              </div>
            </motion.aside>
          )}
        </AnimatePresence>

        {/* Global Help Suggestion Board Drawer overlay */}
        <AnimatePresence>
          {showHelp && (
            <motion.aside
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 50 }}
              transition={{ duration: 0.25 }}
              className="w-full md:w-[340px] flex flex-col border border-white/5 bg-black/40 backdrop-blur-xl rounded-3xl p-6 overflow-hidden shadow-2xl relative z-20"
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-white/5 pb-4 mb-4 select-none">
                <div className="flex items-center space-x-2 text-indigo-400">
                  <Flame size={16} />
                  <span className="text-[10px] uppercase tracking-[0.2em] font-extrabold text-white/60">Tease & Talk Prompts</span>
                </div>
                <button 
                  onClick={() => setShowHelp(false)} 
                  className="p-1 text-white/40 hover:text-white rounded-full hover:bg-white/5 transition-colors"
                >
                  <X size={14} />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto space-y-4 pr-1 select-none custom-scrollbar">
                <div>
                  <h4 className="text-[9px] font-extrabold text-white/30 tracking-[0.25em] uppercase mb-1.5">NV'S BIO MATRIX</h4>
                  <p className="text-xs text-white/60 leading-relaxed bg-white/2 p-3 outline outline-white/5 rounded-xl">
                    NV rejects typical conversational rules. She speaks like a charming, sassy, direct confidante using fluent Hinglish (mix of Hindi & English) and PG-13 chemistry to tease you and judge your vibe.
                  </p>
                </div>

                <div>
                  <h4 className="text-[9px] font-extrabold text-[#ff2d55] tracking-[0.25em] uppercase mb-2">SUGGESTED VOICES</h4>
                  <div className="space-y-2">
                    {SUGGESTED_PROMPTS.map((prompt, i) => (
                      <div 
                        key={i}
                        className="p-3 bg-white/2 border border-white/5 hover:border-violet-500/20 rounded-xl text-white/80 hover:text-white text-xs transition-colors duration-300 flex items-start gap-1.5 cursor-help"
                      >
                        <span className="text-[#a259ff] font-mono font-bold">{i+1}.</span>
                        <span>"{prompt}"</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="text-[9px] font-extrabold text-white/30 tracking-[0.25em] uppercase mb-1.5">TELEMETRY GUIDELINES</h4>
                  <ul className="text-[10px] text-white/40 space-y-2 leading-relaxed">
                    <li className="flex items-start gap-1.5">
                      <span className="text-rose-500 mt-0.5">●</span>
                      <span><strong>Dynamic Interrupt</strong>: Instantly talk over NV's speaking patterns to pause her audio context.</span>
                    </li>
                    <li className="flex items-start gap-1.5">
                      <span className="text-rose-500 mt-0.5">●</span>
                      <span><strong>Instant Web Integrator</strong>: Sassy voice cues command automatic website override triggers seamlessly.</span>
                    </li>
                  </ul>
                </div>
              </div>
            </motion.aside>
          )}
        </AnimatePresence>

      </main>

      {/* Decorative Minimalist Equalizer & Bottom Bar */}
      <footer className="relative z-10 w-full space-y-8 px-8 pb-8 pt-2 bg-black/10">
        
        {/* Dynamic Equalizer Bar Visualizer */}
        <div className="flex items-end justify-center space-x-1 h-12 relative z-10 transition-all duration-300">
          {pulseWave.map((h, index) => {
            // Apply gradient accents across mid levels
            const isMiddle = index >= 4 && index <= 7;
            const customBg = isMiddle 
              ? "bg-[#ff2d55] shadow-[0_0_15px_#ff2d55]" 
              : "bg-[#a259ff] shadow-[0_0_15px_#a259ff]";
            
            return (
              <motion.div
                key={index}
                animate={{ height: h }}
                className={`w-1 rounded-full transition-all duration-75 ${
                  sessionState === "disconnected" ? "bg-white/10 h-1.5" : customBg
                }`}
              />
            );
          })}
        </div>

        {/* Action Controls Footer */}
        <div className="flex flex-col md:flex-row justify-between items-center border-t border-white/10 pt-6 gap-4">
          
          <div className="flex flex-col items-center md:items-start select-none">
            <span className="text-[10px] text-white/30 font-bold uppercase tracking-[0.2em] mb-1">Active Model Mode</span>
            <span className="text-xs font-semibold tracking-wider text-white/90">Sassy, Flirty & Witty</span>
          </div>
          
          <div className="flex space-x-3">
            <button 
              onClick={handlePowerClick}
              className={`px-6 py-2 rounded-full text-[10px] font-extrabold uppercase tracking-[0.2em] transition-all duration-300 ${
                sessionState === "disconnected" 
                  ? "bg-white text-black hover:bg-white/90" 
                  : "bg-transparent border border-white/20 hover:bg-white/10 text-white"
              }`}
            >
              {sessionState === "disconnected" ? "Launch Core" : "End Session"}
            </button>
            
            {sessionState !== "disconnected" && (
              <button 
                onClick={toggleMute}
                className="px-6 py-2 bg-[#ff2d55]/10 hover:bg-[#ff2d55]/20 text-[#ff2d55] border border-[#ff2d55]/20 rounded-full text-[10px] font-extrabold uppercase tracking-[0.2em] transition-all duration-300"
              >
                {muted ? "Unmute Voice" : "Mute Speaker"}
              </button>
            )}
          </div>

          <div className="flex flex-col items-center md:items-end select-none">
            <span className="text-[10px] text-white/30 font-bold uppercase tracking-[0.2em] mb-1">Status Emotion</span>
            <span className="text-xs font-semibold tracking-wider text-[#ff2d55]">Playfully Teasing</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
